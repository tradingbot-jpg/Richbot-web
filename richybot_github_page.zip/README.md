
# RichyBot Download-Seite

Dies ist eine einfache GitHub Page zum Herunterladen der `RichyBot.apk`.

## Nutzung

1. Dieses Repository auf GitHub hochladen
2. GitHub Pages aktivieren (`main` branch → `/ (root)`)
3. Die Seite ist unter `https://<dein-benutzername>.github.io/<repo-name>/` erreichbar
